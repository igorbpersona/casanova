void thread_setup(void);
void thread_cleanup(void);

